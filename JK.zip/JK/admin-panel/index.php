<?php
session_start();
include '../dbConfig.php';
if (empty($_SESSION['is_logged_in'])){
header("Location: ../login.php");
}
$login_data = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM panel WHERE _username = '".$_SESSION['is_logged_in']."'"));
$notif = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM nt WHERE n = 'all'" ));
if ($login_data['_user_type'] != "admin") {
	header("Location: ../login.php");
	exit();
}
$dados_editar = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM server WHERE srv_id=1"));
$fetch_server = mysqli_query($con, "SELECT * FROM server WHERE srv_id = '1'");
$server_data = mysqli_fetch_assoc($fetch_server);
$online = 'online';
$offline = 'offline';
$main = 'maintenance';
$online1 = 'Online';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Najmul101 - Dashboard</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">


	<?php include('header.php'); ?>



            <!-- Sale & Revenue Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                   
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                                                            <p class="mb-2">Total Sessions</p>
                                <h6 class="mb-0"><?php echo ''.$server_data['total_sessions'].'';?></h6>
                            <div class="ms-3">
<i class="fa fa-eye fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                                                            <p class="mb-2">Your Role</p>
                                <h6 class="mb-0">Admin</h6>
                            <div class="ms-3">
<i class="fa fa-user-circle fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                                                            <p class="mb-2">Total Members</p>
                                <h6 class="mb-0"><?php $fetch_t = mysqli_query($con, "SELECT * FROM panel WHERE _user_type = 'member'");
	$count = mysqli_num_rows($fetch_t);
	echo $count; ?></h6>
                            <div class="ms-3">
<i class="fa fa-user fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>

                                        <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                                                            <p class="mb-2">Total Banned Members</p>
                                <h6 class="mb-0"><?php $fetch_t = mysqli_query($con, "SELECT * FROM panel WHERE _status = 'banned'");
	$count = mysqli_num_rows($fetch_t);
	echo $count; ?></h6>
                            <div class="ms-3">
<i class="fa fa-user-slash fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                                                            <p class="mb-2">Total Resellers</p>
                                <h6 class="mb-0"><?php $fetch_t = mysqli_query($con, "SELECT * FROM panel WHERE _user_type = 'reseller'");
	$count = mysqli_num_rows($fetch_t);
	echo $count; ?></h6>
                            <div class="ms-3">
<i class="fa fa-user-friends fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                    
                    
                                                            <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                                                            <p class="mb-2">Total Credits</p>
                                <h6 class="mb-0">Unlimited</h6>
                            <div class="ms-3">
<i class="fa fa-money-check-alt fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                                <?php if ($server_data['server_h_status'] == $online) { ?>
                    
                                                            <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                                                            <p class="mb-2">Apk Status</p>
                                <h6 class="mb-0">Online</h6>
                            <div class="ms-3">
<i class="fab fa-app-store fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>            <?php } ?>
                     <?php if ($server_data['server_h_status'] == $offline) { ?>
                    
                                                            <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                                                            <p class="mb-2">Apk Status</p>
                                <h6 class="mb-0">Offline</h6>
                            <div class="ms-3">
<i class="fab fa-app-store fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                                <?php } ?>
                                <?php if ($server_data['status'] == $online) { ?>
                                                            <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                                                            <p class="mb-2">Server Status</p>
                                <h6 class="mb-0">Online</h6>
                            <div class="ms-3">
<i class="fa fa-cog fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                                                              <?php } ?>
                                                            
                                                                             <?php if ($server_data['status'] == $offline) { ?>               <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                                                            <p class="mb-2">Server Status</p>
                                <h6 class="mb-0">Offline</h6>
                            <div class="ms-3">
<i class="fa fa-cog fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                                <?php } ?>
                                
                                                                                                             <?php if ($server_data['status'] == $main) { ?>               <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                                                            <p class="mb-2">Server Status</p>
                                <h6 class="mb-0">Maintenance</h6>
                            <div class="ms-3">
<i class="fa fa-cog fa-2x text-primary"></i>
                            </div>
                        </div>
                    </div>
                                <?php } ?>
                    
                   

               
                                   <div class="col-12">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">All Files</h6>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            	<th>ApkName</th>
												<th>FileType</th>
		<th>FileStatus</th>
			<th>LastUpdate</th>
			<th>Version</th>
                    <th>Download</th>
                   
                  </tr>
                  </thead>
                  <tbody>
	<?php 
									
									//$admins=$row['username'];
									$query_apps = mysqli_query($con,"SELECT * FROM apps WHERE `ptype` = 'all' ORDER BY id ASC");
									/*
									$cur_user = $_SESSION['user_logado'];
									$query_users = mysqli_query($con,"SELECT * FROM tokens WHERE 'Vendedor' = $cur_user");
									print_r($query_users);
									*/
									while ($row = mysqli_fetch_assoc($query_apps)) {
									?>
					
												<tr>
												
											        <td><?php echo $row['pname'];?></td>
											        
												<th><?php 
											if($row['type'] == "mod"){
											echo "<span class='badge border border-info text-info mt-1'><i class=''></i> Mod Apk</span>"; 
										}else if($row['type'] == "script"){
											echo "<span class='badge border border-warning text-warning mt-1'><i class=' '></i> Script</span>";
										}else if($row['type'] == "injector"){
											echo "<span class='badge border border-danger text-danger mt-1'><i class=''></i>Injector</span>";
												}else if($row['type'] == "zip"){
											echo "<span class='badge border border-success text-success mt-1'><i class=''></i>Zip</span>";
										}
										?></td>
											        
											
		<th><?php 
										if($row['pstatus'] == "online"){
											echo "<span class='badge border border-success text-success mt-1'><i class='fas fa-circle-check '></i> Online</span>"; 
										}else if($row['pstatus'] == "maintenance"){
											echo "<span class='badge border border-warning text-warning mt-1'><i class='fas fa-triangle-exclamation '></i> Maintenance</span>";
										}else{
											echo "<span class='badge border border-danger text-danger mt-1'><i class='fas fa-circle-xmark '></i> Offline</span>";
										}
										?></td>
										        
										        <td><?php echo $row['pupdate'];?></td>
										        <td><?php echo $row['pversion'];?></td>
										        
										        	
											<td><a href="<?php echo $row['phref'];?>"><button type="button" class="btn btn-outline-primary">Download</button></a></td>
									

												</tr>
												<?php
}
?>

                </table>
					</div>
				</div>
				</div>
				</div>
            <!-- Sale & Revenue End -->


            <!-- Sales Chart Start -->
       
            <!-- Widgets End -->


            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">

            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/lib/chart/chart.min.js"></script>
    <script src="../assets/lib/easing/easing.min.js"></script>
    <script src="../assets/lib/waypoints/waypoints.min.js"></script>
    <script src="../assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="../assets/js/main.js"></script>
</body>

</html>