<?php
session_start();
include '../dbConfig.php';
if (empty($_SESSION['is_logged_in'])){
header("Location: ../login.php");
}
$login_data = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM panel WHERE _username = '".$_SESSION['is_logged_in']."'"));
$notif = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM nt WHERE n = 'all'" ));
if ($login_data['_user_type'] != "admin" && $login_data['_user_type'] != "reseller") {
	header("Location: ../login.php");
}
if ($login_data['_user_type'] != "admin"){
header("Location: index.php");
	exit();
}

if (isset($_GET['mainprid'])) {
	$mainprID = $_GET['mainprid'];
	if ($login_data['_user_type'] == "admin") {
	$msg = mysqli_query($con, "UPDATE apps SET `pstatus` = 'maintenance' WHERE pname = '$mainprID'");
	if($msg) {
    $_SESSION['inc']= "<script>swal({title:'Success',text:'Apk Has Been Maintenance Successfully',type:'success'});</script>";
	
	}
	}
}

if (isset($_GET['onlineprid'])) {
	$onlineprID = $_GET['onlineprid'];
	if ($login_data['_user_type'] == "admin") {
	$msg = mysqli_query($con, "UPDATE apps SET `pstatus` = 'online' WHERE pname = '$onlineprID'");
	if($msg) {
    $_SESSION['inc']= "<script>swal({title:'Success',text:'Apk Has Been Online Successfully',type:'success'});</script>";
		
	}
}
}

if (isset($_GET['delete'])) {
    $dt = $_GET['delete'];
		$pname = isset($_POST['pname']) ? $_POST['pname'] : '';
	$ptype = 'all';
	$pnamechecked = mysqli_real_escape_string($con, $pname);
	$ptypechecked = mysqli_real_escape_string($con, $ptype);
	
	if ($ptypechecked) {
		$query = mysqli_query($con, "DELETE FROM apps WHERE pname = '$dt'");
		if ($query) {
		    $_SESSION['inc']= "<script>swal({title:'Success',text:'Apk Has Been Deleted Successfully',type:'success'});</script>";
		} else {
		    	$_SESSION['inc'] = "<script>swal('Error', 'Failed To Add User Exception : 408', 'error');</script>";
		}
	}
  }
  
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Najmul101 - Manage Files</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../assets/css/style.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../styles/sweetalert.min.css"/>
  <script src="../scripts/sweetalert.min.js"></script>
  
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">


	<?php include('header.php'); ?>



            <!-- Sale & Revenue Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                   

               
                                   <div class="col-12">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h4 class="mb-4">Files Management</h4>
                            	<?php if (!empty($_SESSION['inc'])) { ?>
<?php echo $_SESSION['inc'];
unset($_SESSION['inc']);?>
<?php } ?>
<div class="card-datatable text-nowrap">
  <div class="table-responsive">
    <table class="datatables-ajax table table-bordered">
                              
                                    <thead>
                                        <tr>
<tr>
							
													<th>FileName</th>
												<th>FileType</th>
		<th>FileStatus</th>
			<th>LastUpdate</th>
			<th>Version</th>
											
												
	<th>Update/Delete File</th>

                  </tr>
                  </thead>
                  <tbody>
    	<?php 
									
									//$admins=$row['username'];
									$query_apps = mysqli_query($con,"SELECT * FROM apps WHERE `ptype` = 'all' ORDER BY id ASC");
									/*
									$cur_user = $_SESSION['user_logado'];
									$query_users = mysqli_query($con,"SELECT * FROM tokens WHERE 'Vendedor' = $cur_user");
									print_r($query_users);
									*/
									while ($row = mysqli_fetch_assoc($query_apps)) {
									?>
					
												<tr>
												
											        <td><?php echo $row['pname'];?></td>
											        
												<th><?php 
											if($row['type'] == "mod"){
											echo "<span class='badge border border-info text-info mt-1'><i class=''></i> Mod Apk</span>"; 
										}else if($row['type'] == "script"){
											echo "<span class='badge border border-warning text-warning mt-1'><i class=' '></i> Script</span>";
										}else if($row['type'] == "injector"){
											echo "<span class='badge border border-danger text-danger mt-1'><i class=''></i>Injector</span>";
												}else if($row['type'] == "zip"){
											echo "<span class='badge border border-success text-success mt-1'><i class=''></i>Zip</span>";
										}
										?></td>
											        
											
		<th><?php 
										if($row['pstatus'] == "online"){
											echo "<span class='badge border border-success text-success mt-1'><i class='fas fa-circle-check '></i> Online</span>"; 
										}else if($row['pstatus'] == "maintenance"){
											echo "<span class='badge border border-warning text-warning mt-1'><i class='fas fa-triangle-exclamation '></i> Maintenance</span>";
										}else{
											echo "<span class='badge border border-danger text-danger mt-1'><i class='fas fa-circle-xmark '></i> Offline</span>";
										}
										?></td>
										        
										        <td><?php echo $row['pupdate'];?></td>
										        <td><?php echo $row['pversion'];?></td>
											<th><div class="btn-group text-xs btn-xs" role="group" aria-label="Basic example">

 <a href="manage-file.php?onlineprid=<?php echo $row['pname'];?>"><button type="button" class="btn btn-primary ml-1 text-xs" onClick="return confirm('Do you really want to Online?');" style="margin: 0px 0px 0px 2px; background-color:#9124E6; border-color:#9124E6"><i class="fas fa-play"></i></button></a>
  <a href="manage-file.php?mainprid=<?php echo $row['pname'];?>"><button type="button" class="btn btn-primary ml-1 text-xs" onClick="return confirm('Do you really want to Maintenance?');" style="margin: 0px 0px 0px 2px; background-color:#FF9933; border-color:#FF9933"><i class="fas fa-ban"></i></button></a>
 
  
    <a href="manage-file.php?delete=<?php echo $row['pname'];?>"><button type="button" class="btn btn-primary ml-1 text-xs" onClick="return confirm('Do you really want to Delete?');" style="margin: 0px 0px 0px 2px; background-color:#FF005C; border-color:#FF005C"><i class="fa fa-trash"></i></button></a>
</div>
										
									

												</tr>
												<?php
}
?>
                  </td>

                   
										</tr>
											
                </table>
					</div>
				</div>
				</div>
				</div>

            <!-- Sale & Revenue End -->


            <!-- Sales Chart Start -->
       
            <!-- Widgets End -->


            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">

            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/lib/chart/chart.min.js"></script>
    <script src="../assets/lib/easing/easing.min.js"></script>
    <script src="../assets/lib/waypoints/waypoints.min.js"></script>
    <script src="../assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="../assets/js/main.js"></script>
</body>

</html>