<?php
session_start();
include '../dbConfig.php';
if (empty($_SESSION['is_logged_in'])){
header("Location: ../login.php");
}
$login_data = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM panel WHERE _username = '".$_SESSION['is_logged_in']."'"));
$notif = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM nt WHERE n = 'all'" ));
if ($login_data['_user_type'] != "admin" && $login_data['_user_type'] != "reseller") {
	header("Location: ../login.php");
}
if ($login_data['_user_type'] != "admin"){
header("Location: index.php");
}
$fetch_server = mysqli_query($con, "SELECT * FROM server WHERE server_h_status = 'online'");
$server_data = mysqli_fetch_assoc($fetch_server);
$online = 'online';
if (isset($_POST['password'])){
if (empty($_POST['username'])){
$_SESSION['inc'] = "<script>swal('Error', 'Username Field Is Empty', 'error');</script>";
} else if (empty($_POST['password'])){
$_SESSION['inc'] = "<script>swal('Error', 'Password Field Is Empty', 'error');</script>";
} else if (empty($_POST['token'])){
$_SESSION['inc'] = "<script>swal('Error', 'Token Field Is Empty', 'error');</script>";
} else if (empty($_POST['money'])){
$_SESSION['inc'] = "<script>swal('Error', 'Money Field Is Empty', 'error');</script>";
} else if (empty($_POST['resets'])){
$_SESSION['inc'] = "<script>swal('Error', 'Resets Field Is Empty', 'error');</script>";
}
date_default_timezone_set('Asia/Dhaka');
$username = $_POST['username'];
$password = $_POST['password'];
$token = date("h:i:s");
$verify = 'verified';
$status = 'active';
$reg_date = date("Y/m/d h:i");
$exp_date = Date('Y-m-d h:i', strtotime('+999 day'));
$curr_time = date("Y/m/d h:i"); 
$user_role = 'admin';
$money = '9999';
$registrar = $_POST['registrar'];
$version = 'injector';
$p_status = 'paid';
$resets = '10';
$is_verified = '1';
$check_if_exists = mysqli_num_rows(mysqli_query($con, "SELECT * FROM panel WHERE _username = '$username'"));
		if ($check_if_exists > 0) {
		$_SESSION['inc'] = "<script>swal('Error', 'Failed To Add User Exception : User Already Exists', 'error');</script>";
    } else {
 if ($login_data['_user_type'] == "admin"){
	$insert = mysqli_query($con, "INSERT INTO `panel` (`_username`, `_password`, `_token`, `_v_status`, `_status`, `_reg_date`, `_exp_date`, `_curr_time`, `_uid`, `_user_type`, `_registrar`, `_version`, `_p_status`, `_credits`, `_resets`, `_r_resets`, `is_verified`) VALUES ('$username', '$password', '$token', '$verify', 'active', '$reg_date', '$exp_date', '$reg_date', NULL, '$user_role', '$registrar', '$version', 'paid', '$money', '0', '$resets', '$is_verified');");
	if ($insert){
	$update_money = $login_data['_credits'] - 1;
	$update_query = mysqli_query($con, "UPDATE `panel` SET `_credits` = '$update_money' WHERE _username = '".$_SESSION['is_logged_in']."'");
  $_SESSION['inc']= "<script>swal({title:'Success',text:'User Has Been Added Successfully',type:'success'});</script>";
	} else {
	$_SESSION['inc'] = "<script>swal('Error', 'Failed To Add User Exception : 408', 'error');</script>";
	}
	} else {
	$_SESSION['inc'] = "<script>swal('Error', 'Failed To Add User Exception : 405', 'error');</script>";
	}
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Najmul101 - Add Admin</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../styles/sweetalert.min.css"/>
  <script src="../scripts/sweetalert.min.js"></script>
  
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">


	<?php include('header.php'); ?>

            <!-- Form Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                
    
    
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h4 class="mb-4">Add Admin</h4>
                            	<?php if (!empty($_SESSION['inc'])) { ?>
<?php echo $_SESSION['inc'];
unset($_SESSION['inc']);?>
<?php } ?>

<form class="dt_adv_search" method="POST">
                                <div class="row mb-3">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Username</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" type="text" name="username" placeholder="Enter A Username">
                                    </div>
                                </div>
<div class="row mb-3">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Password</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" placeholder="Enter A Password" name="password" type="text">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Admin</label>
                                    <div class="col-sm-10">
                                        <input readonly class="form-control" type="text" name="registrar" type="text" placeholder="" value="<?php echo $login_data['_username'];?>">
                                    </div>
                                </div>
                                <div class="row mb-3">

                                    <label for="inputEmail3" class="col-sm-2 col-form-label">User Type</label>
                                    <div class="col-sm-10">
                                        	<select class="form-select" name="">
                                        <option value="">Reseller</option>
                                        </select>
                                    </div>
                                </div>


<div class="row mb-3">


                               <hr>
                               	<div align="right">
                                <button type="submit" class="btn btn-outline-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                   </div>
            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">

                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/lib/chart/chart.min.js"></script>
    <script src="../assets/lib/easing/easing.min.js"></script>
    <script src="../assets/lib/waypoints/waypoints.min.js"></script>
    <script src="../assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="../assets/js/main.js"></script>
</body>

</html>