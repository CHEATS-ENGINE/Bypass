<?php
session_start();
include '../dbConfig.php';
if (empty($_SESSION['is_logged_in'])){
header("Location: ../login.php");
}
$login_data = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM panel WHERE _username = '".$_SESSION['is_logged_in']."'"));
$notif = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM nt WHERE n = 'all'" ));
if ($login_data['_user_type'] != "admin" && $login_data['_user_type'] != "member" && $login_data['_user_type'] != "reseller") {
	header("Location: ../login.php");
	exit();
}
$fetch_server = mysqli_query($con, "SELECT * FROM server WHERE server_h_status = 'online'");
$server_data = mysqli_fetch_assoc($fetch_server);
$online = 'online';
if (isset($_POST['value_2'])){
$old_pass = $_POST['value_1'];
$new_pass = $_POST['value_2'];
$cn_pass = $_POST['value_3'];
if (empty($new_pass)){
$_SESSION['inc'] = "<script>swal('Error', 'New Password Field Is Empty', 'error');</script>";
} else if (empty($cn_pass)){
$_SESSION['inc'] = "<script>swal('Error', 'Confirm New Password Field Is Empty', 'error');</script>";
} else {
if ($new_pass == $old_pass){
$_SESSION['inc'] = "<script>swal('Error', 'New Password Should Not Be Equal To Your Old Password', 'error');</script>";
} else if ($new_pass == $cn_pass){
$update_query = mysqli_query($con, "UPDATE panel SET _password = '$cn_pass' WHERE _username = '".$_SESSION['is_logged_in']."'");
if ($update_query){
$_SESSION['inc'] = "<script>swal('Success', 'Your Password Has Been Changed Successfully', 'success');</script>";
} else {
$_SESSION['inc'] = "<script>swal('Failed', 'Failed To Change Your Password', 'error');</script>";
}
} else {
$_SESSION['inc'] = "<script>swal('Error', 'New Password Should Be Equal To Confirm Password', 'error');</script>";
}
}
}
if (isset($_POST['reset'])){
if ($login_data['_uid'] != NULL){
if ($login_data['_r_resets'] < $login_data['_resets']){
$_SESSION['inc'] = "<script>swal('Failed', 'Your Reset Limit Has Been Exceeded', 'error');</script>";
} else {
$reset_query = mysqli_query($con, "UPDATE panel SET _uid = NULL WHERE _username = '".$_SESSION['is_logged_in']."'");
if ($reset_query){
$inc_resets = $login_data['_resets'] + 1;
$reset_query = mysqli_query($con, "UPDATE panel SET _resets = '$inc_resets' WHERE _username = '".$_SESSION['is_logged_in']."'");
$_SESSION['inc'] = "<script>swal('Success', 'Your Account Has Been Reseted Successfully', 'success');</script>";
} else {
$_SESSION['inc'] = "<script>swal('Failed', 'Failed To Reset Your Account', 'error');</script>";
}
}
} else {
$_SESSION['inc'] = "<script>swal('Failed', 'Your Account Is Not Connected To Any Device', 'error');</script>";
}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Najmul101 - Profile</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../styles/sweetalert.min.css"/>
  <script src="../scripts/sweetalert.min.js"></script>
  
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">


	<?php include('header.php'); ?>

            <!-- Form Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                
    
    
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h4 class="mb-4"></h4>
                            	<?php if (!empty($_SESSION['inc'])) { ?>
<?php echo $_SESSION['inc'];
unset($_SESSION['inc']);?>
<?php } ?>

<form class="dt_adv_search" method="POST">
    
      <div class="user-profile-header d-flex flex-column flex-sm-row text-sm-start text-center mb-4">
        <div class="flex-shrink-0 mt-n2 mx-sm-0 mx-auto">
                  <img src="../assets/img/1.jpg" alt class="w-px-100 h-auto rounded-circle">
        </div>
        <div class="flex-grow-1 mt-3 mt-sm-5">
          <div class="d-flex align-items-md-end align-items-sm-start align-items-center justify-content-md-between justify-content-start mx-4 flex-md-row flex-column gap-4">
            <div class="user-profile-info">
              <h4><?php echo ''.$_SESSION['is_logged_in'].'';?></h4>

            </div>

          </div>
        </div>

      <div class="card-body">
        <small class="text-muted text-uppercase">About</small>
        <ul class="list-unstyled mb-4 mt-3">
          <li class="d-flex align-items-center mb-3"><span class="fw-semibold mx-2">Username :</span> <span><?php echo ''.$_SESSION['is_logged_in'].'';?></span></li>

          <li class="d-flex align-items-center mb-3"><span class="fw-semibold mx-2">Role :</span> <span>Admin</span></li>

          <li class="d-flex align-items-center mb-3"><span class="fw-semibold mx-2">Credits :</span> <span>Unlimited</span></li>
          <li class="d-flex align-items-center mb-3"><span class="fw-semibold mx-2">Provider :</span> <span><?php echo ''.$login_data['_registrar'].'';?></span></li>


        </ul>

      </div>
    </div>
                            </form>
                        </div>
                    </div>
                   </div>
                               <div class="pt-4 px-0">
                <div class="row g-4">
                
    
    
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            </form>
                        </div>
                    </div>
                   </div>
            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">

                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/lib/chart/chart.min.js"></script>
    <script src="../assets/lib/easing/easing.min.js"></script>
    <script src="../assets/lib/waypoints/waypoints.min.js"></script>
    <script src="../assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="../assets/js/main.js"></script>
</body>

</html>