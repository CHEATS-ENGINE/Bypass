<?php
session_start();
include '../dbConfig.php';
if (empty($_SESSION['is_logged_in'])){
header("Location: ../login.php");
}
$login_data = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM panel WHERE _username = '".$_SESSION['is_logged_in']."'"));
$notif = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM nt WHERE n = 'all'" ));
if ($login_data['_user_type'] != "admin" && $login_data['_user_type'] != "reseller") {
	header("Location: ../login.php");
}
if ($login_data['_user_type'] != "admin"){
header("Location: index.php");
	exit();
}


if (isset($_GET['mainprid'])) {
	$mainprID = $_GET['mainprid'];
	if ($dados_logado['_user_type'] == "admin") {
	$msg = mysqli_query($con, "UPDATE apps SET `pstatus` = 'maintenance' WHERE pname = '$mainprID'");
	if($msg) {
	$_SESSION['acao'] = "<script>swal('Warning', 'Product : $mainprID Is Now Under Maintenance', 'warning');</script>";
	
	}
	}
}

if (isset($_GET['onlineprid'])) {
	$onlineprID = $_GET['onlineprid'];
	if ($dados_logado['_user_type'] == "admin") {
	$msg = mysqli_query($con, "UPDATE apps SET `pstatus` = 'online' WHERE pname = '$onlineprID'");
	if($msg) {
	$_SESSION['acao'] = "<script>swal('Successo', 'Product : $onlineprID Is Now Online', 'success');</script>";
		
	}
}
}

if (isset($_GET['delete'])){
		$nt = isset($_POST['nt']) ? $_POST['nt'] : '';
		$ntchecked = mysqli_real_escape_string($con, $nt);
$delete = $_GET['delete'];
$check = mysqli_num_rows(mysqli_query($con, "SELECT * FROM nt WHERE nt = '$delete'"));
if ($check == 1){
$delete = mysqli_query($con, "DELETE FROM nt WHERE nt = '$delete'");
		if ($delete) {
		    $_SESSION['acao'] = "<script>swal('Successo', 'Notif : $ntchecked Has Been Deleted', 'success');</script>";
		    header("Location: manage-notif.php");
	exit();
		} else {
		    $_SESSION['acao'] = "<script>swal('Error', 'Failed!', 'error');</script>";
		    
		}
}
}

if (isset($_POST['Delete'])) {
		$nt = isset($_POST['nt']) ? $_POST['nt'] : '';
		$dt = isset($_POST['dt']) ? $_POST['dt'] : '';
	$n = 'all';
	$ntchecked = mysqli_real_escape_string($con, $nt);
	$dtchecked = mysqli_real_escape_string($con, $dt);
	$nchecked = mysqli_real_escape_string($con, $n);
	
	if ($nchecked) {
		$query = mysqli_query($con, "DELETE FROM nt WHERE nt = '$ntchecked'");
		if ($query) {
		    $_SESSION['acao'] = "<script>swal('Successo', 'Notif Has Been Deleted', 'success');</script>";
		    header("Location: manage-notif.php");
	exit();
		} else {
		    $_SESSION['acao'] = "<script>swal('Error', 'Failed!', 'error');</script>";
		}
	}
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Najmul101 - Manage Notif</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../assets/css/style.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../styles/sweetalert.min.css"/>
  <script src="../scripts/sweetalert.min.js"></script>
  
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">


	<?php include('header.php'); ?>



            <!-- Sale & Revenue Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                   

               
                                   <div class="col-12">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h4 class="mb-4">Notif Management</h4>
                            	<?php if(!empty($_SESSION['acao'])){ echo $_SESSION['acao'].'<hr>'; unset($_SESSION['acao']); }?>
<div class="card-datatable text-nowrap">
  <div class="table-responsive">
    <table class="datatables-ajax table table-bordered">
                              
                                    <thead>
                                        <tr>
<tr>
									<th>#</th>
													<th>Notification</th>
		<th>Sented Date</th>
											
												
	<th>Action</th>

		</thead>									<tbody>				<?php 
									
									//$admins=$row['username'];
									$query_nt = mysqli_query($con,"SELECT * FROM nt WHERE `n` = 'all' ORDER BY id ASC");
									/*
									$cur_user = $_SESSION['user_logado'];
									$query_users = mysqli_query($con,"SELECT * FROM tokens WHERE 'Vendedor' = $cur_user");
									print_r($query_users);
									*/
									while ($row = mysqli_fetch_assoc($query_nt)) {
									?>
					
												<tr>
													<td><span class="fa fa-bell bx-sm"></span></td>
											        <td><?php echo $row['nt'];?></td>
											                <td><?php echo $row['dt'];?></td>
		
																			<th><div class="btn-group text-xs btn-xs" role="group" aria-label="Basic example">
      <a href="manage-notif.php?delete=<?php echo $row['nt'];?>"><button type="button" class="btn btn-primary ml-1 text-xs" onClick="return confirm('Do you really want to Delete?');" style="margin: 0px 0px 0px 2px; background-color:#FF005C; border-color:#FF005C"><i class="fa fa-trash"></i></button></a>


</div>
										
									

												</tr>
												<?php
}
?>
	
		
 
              </tr>
										</tbody>
						</table>
					</div>
				</div>
				</div>
				</div>

            <!-- Sale & Revenue End -->


            <!-- Sales Chart Start -->
       
            <!-- Widgets End -->


            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">

            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/lib/chart/chart.min.js"></script>
    <script src="../assets/lib/easing/easing.min.js"></script>
    <script src="../assets/lib/waypoints/waypoints.min.js"></script>
    <script src="../assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="../assets/js/main.js"></script>
</body>

</html>