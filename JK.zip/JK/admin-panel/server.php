<?php
session_start();
include '../dbConfig.php';
if (empty($_SESSION['is_logged_in'])){
header("Location: ../login.php");
}

$login_data = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM panel WHERE _username = '".$_SESSION['is_logged_in']."'"));
$notif = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM nt WHERE n = 'all'" ));
if ($login_data['_user_type'] != "admin") {
	header("Location: ../login.php");
}
$fetch_server = mysqli_query($con, "SELECT * FROM server WHERE server_name = 'panel'");
$server_data = mysqli_fetch_assoc($fetch_server);
$online = 'online';
if (isset($_POST['status'])){
date_default_timezone_set('Asia/Kolkata');
$status = $_POST['status'];
$h_status = $_POST['h_status'];
$n_status = $_POST['n_status'];
		if ($login_data['_user_type'] == "admin") {
	$update_query = mysqli_query($con, "UPDATE server SET `server_status` = '$status', server_h_status = '$h_status', `status` = '$n_status' WHERE server_name = 'panel'");
if ($update_query){
$_SESSION['inc'] = "<script>swal('Success', 'Server Settings Has Been Updated', 'success');</script>";
} else {
$_SESSION['inc'] = "<script>swal('Failed', 'Failed To Run Query', 'error');</script>";
}
} else {
$_SESSION['inc'] = "<script>swal('Failed', 'Incorrect Username', 'error');</script>";
}
}
$dados_editar = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM server WHERE srv_id=1"));

if (isset($_POST['Submit'])) {
	$tatus = isset($_POST['tatus']) ? $_POST['tatus'] : '';
	$tatuschecked = mysqli_real_escape_string($con, $tatus);

	$check = mysqli_num_rows(mysqli_query($con, "SELECT * FROM tatus WHERE tatus = '$tatuschecked'"));
	if ($check > 0) {
		$_SESSION['acao'] = "<script>swal('Error', 'Status Already Change', 'error');</script>";
	} else {
     $query = mysqli_query($con, "UPDATE tatus SET tatus = '$tatuschecked' WHERE id=11");
		if ($query) {
			$_SESSION['acao'] = "<script>setTimeout(function(){swal({title:'Successo',text:'Status : $tatuschecked',type:'success'},function(){window.location = '';});},100);</script>";
		} else {
		    $_SESSION['acao'] = "<script>swal('Error', 'Failed!', 'error');</script>";
				}
		}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Najmul101 - Manage Server</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../styles/sweetalert.min.css"/>
  <script src="../scripts/sweetalert.min.js"></script>
  
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">


	<?php include('header.php'); ?>

            <!-- Form Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                
    
    
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h4 class="mb-4">Server Management</h4>
                            	<?php if (!empty($_SESSION['inc'])) { ?>
<?php echo $_SESSION['inc'];
unset($_SESSION['inc']);?>
<?php } ?>

<form class="dt_adv_search" method="POST">

                                <div class="row mb-3">

                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Apk Status</label>
                                    <div class="col-sm-10">
                                        	<select class="form-select" name="h_status">
				<option value="online" <?php if($server_data['server_h_status'] == "online"){ echo 'selected'; }?>>Online</option>
				<option value="offline" <?php if($server_data['server_h_status'] == "offline"){ echo 'selected'; }?>>Offline</option>
				</select>
                                    </div>
                                </div>
                                <div style="display:none;">
                                <div class="row mb-3">

                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Server Status</label>
                                    <div class="col-sm-10">
                                        	<select class="form-select" name="status" >
				<option value="online" <?php if($server_data['server_status'] == "online"){ echo 'selected'; }?>>Online</option>
				<option value="offline" <?php if($server_data['server_status'] == "offline"){ echo 'selected'; }?>>Offline</option>
				</select>
                                    </div>
                                </div>
                                	</div>
                                
                                                                <div class="row mb-3">

                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Server Status</label>
                                    <div class="col-sm-10">
                                        	<select class="form-select" name="n_status" >
				<option value="online" <?php if($server_data['status'] == "online"){ echo 'selected'; }?>>Online</option>
				<option value="maintenance" <?php if($server_data['status'] == "maintenance"){ echo 'selected'; }?>>Maintenance</option>
				<option value="offline" <?php if($server_data['status'] == "offline"){ echo 'selected'; }?>>Offline</option>
				</select>
                                    </div>
                                </div>

                               <hr>
                               	<div align="right">
                                <button type="submit" class="btn btn-outline-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                   </div>
            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">

                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/lib/chart/chart.min.js"></script>
    <script src="../assets/lib/easing/easing.min.js"></script>
    <script src="../assets/lib/waypoints/waypoints.min.js"></script>
    <script src="../assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="../assets/js/main.js"></script>
</body>

</html>