<?php
session_start();
include 'dbConfig.php';
if (!empty($_SESSION['is_logged_in'])){
$login_data = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM panel WHERE _username = '".$_SESSION['is_logged_in']."'"));
if ($login_data['_user_type'] == "member"){
header("Location: user-panel/");
} else if ($login_data['_user_type'] == "reseller"){
header("Location: reseller-panel/");
} else if ($login_data['_user_type'] == "admin"){
header("Location: admin-panel/");
}
} else {
$fetch_server = mysqli_query($con, "SELECT * FROM server WHERE server_status = 'online'");
	$server_data = mysqli_fetch_assoc($fetch_server);
	$online = 'online';
 	unset($_SESSION['is_logged_in']);
if (isset($_POST['value_1'])) {
	$value_1 = trim(isset($_POST['value_1']) ? $_POST['value_1'] : '');
	$value_2 = trim(isset($_POST['value_2']) ? $_POST['value_2'] : '');
    $value_1_ = mysqli_real_escape_string($con, $value_1);
	$value_2_ = mysqli_real_escape_string($con, $value_2);
	   if($server_data['server_status'] == $online){
	   if(empty($value_1)){
	   $_SESSION['inc'] = "<script>swal('Error', 'Username Is Empty', 'warning');</script>";
	   }else if(empty($value_2)){
	   $_SESSION['inc'] = "<script>swal('Error', 'Password Is Empty', 'warning');</script>";
	   }else{
	   
	$fetch = mysqli_query($con, "SELECT * FROM panel WHERE _username = '".$value_1_."' AND _password = '".$value_2_."'");
	$check = mysqli_num_rows($fetch);
	if ($check == 1) {
	$data = mysqli_fetch_assoc($fetch);
	if ($data['is_verified'] == 1 ){
	if ($data['_v_status'] == "verified"){
	if ($data['_status'] == "active"){
	$username = $value_1;
	$_SESSION['is_logged_in'] = $value_1;
	$update_ts = $server_data['total_sessions'] + 1;
	$update_query = mysqli_query($con, "UPDATE server SET total_sessions = $update_ts ");
		if ($data['_user_type'] == "reseller"){
			 $_SESSION['inc']= "<script>setTimeout(function(){swal({title:'Success',text:'Login Success',type:'success'},function(){window.location = 'reseller-panel/';});},100);</script>";
	  
		} else if ($data['_user_type'] == "admin") {
		 $_SESSION['inc']= "<script>setTimeout(function(){swal({title:'Success',text:'Login Success',type:'success'},function(){window.location = 'admin-panel/';});},100);</script>";
	        } else if ($data['_user_type'] == "member") {
            $_SESSION['inc']= "<script>setTimeout(function(){swal({title:'Success',text:'Login Success',type:'success'},function(){window.location = 'user-panel/';});},100);</script>";
	  
		}else{
			$_SESSION['acao'] = "You don't have permission to access this site";
			session_destroy();
		}
		} else {
		$_SESSION['inc'] = "<script>swal('Error', 'Your Account Is Banned', 'warning');</script>";
		}
  }else{
  $_SESSION['inc'] = "<script>swal('Error', 'Your Account Isn't Verified Yet', 'warning');</script>";
  }
  }else{
  $_SESSION['inc'] = "<script>swal('Error', 'Your Email Is Not Verified', 'warning');</script>";
  }
	}else{
		$_SESSION['inc'] = "<script>swal('Error', 'Incorrect Username Or Password', 'error');</script>";
	}
	}
}else{
$_SESSION['inc'] = "<script>swal('Error', 'Server Is Offline', 'error');</script>";
}
}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Najmul101 - Login</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="styles/sweetalert.min.css"/>
  <script src="scripts/sweetalert.min.js"></script>
  
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

	<?php if (!empty($_SESSION['inc'])) { ?>
<?php echo $_SESSION['inc'];
unset($_SESSION['inc']);?>
<?php } ?>
        <!-- Sign In Start -->
        <div class="container-fluid">
            <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
                <div class="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4">
                    <div class="bg-secondary rounded p-4 p-sm-5 my-4 mx-3">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                        
    <form class="dt_adv_search" method="POST">
                             <h1 class="text-center" style="font-weight: bold; margin: 10px;">Login<span style="font-weight: bold; margin: 10px;">BlackFire</span></h1>

                        </div>
                        <div class="form-floating mb-3">
                            <input                     type="text" class="form-control" name="value_1"
                    placeholder="Enter Your Username">
                            <label for="floatingInput">Username</label>
                        </div>
                        <div class="form-floating mb-4">
                            <input type="password" class="form-control" name="value_2" id="value_2"
                      placeholder="Enter Your Password">
                            <label for="floatingPassword">Password</label>
                        </div>

                        <button type="submit" class="btn btn-primary d-grid w-100">Login</button>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- Sign In End -->
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/lib/chart/chart.min.js"></script>
    <script src="assets/lib/easing/easing.min.js"></script>
    <script src="assets/lib/waypoints/waypoints.min.js"></script>
    <script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="assets/js/main.js"></script>
</body>

</html>